TIRE SMOKE CONTROL v0.2.5 — ENGLISH HUD EDITION
================================================

Tire Smoke Control is a BeamNG.drive HUD app for adjusting the stock tire-smoke particle rules. Version 0.2.5 remembers whether the HUD is collapsed when BeamNG recreates the app, such as after opening and closing the game menu.

HUD controls
------------
1. Smoke amount: x0.1–x20, with presets x0.1, x1, x2, x3, x5, x10 and x20.
2. Smoke lifetime: x0.1–x10, with presets x0.5, x1, x2, x3 and x5. x1 is the stock lifetime.
3. Smoke rise: x0–x2, with presets x0, x0.1, x0.25, x0.5, x1 and x2. x0.25 is a recommended slow-rise starting point.
4. The HUD can collapse to a circular smoke icon and expand again by clicking the icon. Its collapsed state is remembered when the HUD reloads.
5. Settings are saved automatically to settings/tireSmokeControl.json.

Installation
------------
1. Close BeamNG.drive.
2. Remove previous Tire Smoke Control ZIPs, including v0.2.4, to avoid duplicate UI apps or overlapping paths.
3. Place Tire_Smoke_Control_v0.2.5_EN.zip in the BeamNG.drive user folder's mods directory. Do not extract the ZIP.
4. Start the game, open ESC -> UI Apps -> Add App, and add "Tire Smoke Control".

How Smoke Rise Works
--------------------
The mod scales the negative gravityCoefficient on supported stock tire-smoke ParticleData objects. x0 disables that upward component; x0.1–x0.25 greatly reduces it; x1 preserves the original value; x2 increases the component. This does not freeze smoke in place: wind, inertia and the emitter's initial velocity can still move the particles.

Technical Notes
---------------
Original lifetimeMS and gravityCoefficient values are cached per ParticleData datablock so values are scaled from their original base instead of multiplying already modified values. The mod modifies shared stock ParticleData objects, so other effects using the same datablock may also be affected, including AI traffic. The smoke amount control modifies the stock RUBBER + ASPHALT particle rules.

Performance
-----------
High smoke amount and lifetime values can increase CPU/GPU workload during prolonged drifting or when many particles are active. The rise setting itself does not create more particles. Suggested starting point: amount x1–x3, lifetime x1–x3, rise x0.25.

Compatibility
-------------
Packaged for BeamNG.drive 0.39.4.0. This is the last game version specified for the project, not confirmation of compatibility with newer releases. The archive and scripts are statically checked; behavior must be verified in-game with the vehicles and effects you use.

Removing the Mod
----------------
Close the game and remove the ZIP from the mods directory. You may keep or manually delete settings/tireSmokeControl.json.
