# Tire Smoke Control — Changelog

## 0.2.5 — 2026-10-19

- Persist the collapsed HUD state through BeamNG's app settings so it stays collapsed after the app is recreated, including when the game menu is opened and closed.

## 0.2.4 — 2026-10-19

- Documentation-only maintenance release: updated the English and Russian README and added a changelog.
- No gameplay code, particle settings, controls, or saved configuration behavior changed from v0.2.3.

